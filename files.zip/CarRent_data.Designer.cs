﻿namespace CAR_RENTAL
{
    partial class CarRent_data
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Carrentdata = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Carrentdata)).BeginInit();
            this.SuspendLayout();
            // 
            // Carrentdata
            // 
            this.Load += CarRent_data_Load;
            this.Carrentdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Carrentdata.Location = new System.Drawing.Point(37, 84);
            this.Carrentdata.Name = "Carrentdata";
            this.Carrentdata.RowHeadersWidth = 51;
            this.Carrentdata.RowTemplate.Height = 24;
            this.Carrentdata.Size = new System.Drawing.Size(838, 307);
            this.Carrentdata.TabIndex = 0;
            // 
            // CarRent_data
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 762);
            this.Controls.Add(this.Carrentdata);
            this.Name = "CarRent_data";
            this.Text = "CarRent_data";
            ((System.ComponentModel.ISupportInitialize)(this.Carrentdata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Carrentdata;
    }
}