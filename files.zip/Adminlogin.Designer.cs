﻿namespace CAR_RENTAL
{
    partial class Adminlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.adminUsernameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.adminPasswordTextBox = new System.Windows.Forms.TextBox();
            this.Alogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labl
            // 
            this.labl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.labl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labl.Location = new System.Drawing.Point(382, 88);
            this.labl.Name = "labl";
            this.labl.Size = new System.Drawing.Size(180, 42);
            this.labl.TabIndex = 0;
            this.labl.Text = "ADMIN LOGIN";
            this.labl.Click += new System.EventHandler(this.labl_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(276, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 51);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Name";
            // 
            // adminUsernameTextBox
            // 
            this.adminUsernameTextBox.Location = new System.Drawing.Point(279, 234);
            this.adminUsernameTextBox.Multiline = true;
            this.adminUsernameTextBox.Name = "adminUsernameTextBox";
            this.adminUsernameTextBox.Size = new System.Drawing.Size(379, 61);
            this.adminUsernameTextBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(274, 324);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(218, 51);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password";
            // 
            // adminPasswordTextBox
            // 
            this.adminPasswordTextBox.Location = new System.Drawing.Point(279, 361);
            this.adminPasswordTextBox.Name = "adminPasswordTextBox";
            this.adminPasswordTextBox.PasswordChar = '*';
            this.adminPasswordTextBox.Size = new System.Drawing.Size(379, 22);
            this.adminPasswordTextBox.TabIndex = 4;
            // 
            // Alogin
            // 
            this.Alogin.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Alogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alogin.Location = new System.Drawing.Point(387, 482);
            this.Alogin.Name = "Alogin";
            this.Alogin.Size = new System.Drawing.Size(151, 56);
            this.Alogin.TabIndex = 5;
            this.Alogin.Text = "Login";
            this.Alogin.UseVisualStyleBackColor = false;
            this.Alogin.Click += new System.EventHandler(this.Alogin_Click);
            // 
            // Adminlogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1061, 757);
            this.Controls.Add(this.Alogin);
            this.Controls.Add(this.adminPasswordTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.adminUsernameTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labl);
            this.Name = "Adminlogin";
            this.Text = "Adminlogin";
            this.Load += new System.EventHandler(this.Adminlogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox adminUsernameTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox adminPasswordTextBox;
        private System.Windows.Forms.Button Alogin;
    }
}