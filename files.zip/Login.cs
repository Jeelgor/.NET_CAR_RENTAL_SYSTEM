﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAR_RENTAL
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string enteredUsername = textBox1.Text;
            string enteredPassword = textBox3.Text;
            

            // Define your database connection string
            string connectionString = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Query the database to find the user with the entered username
                string query = "SELECT Username, Password FROM Users WHERE Username = @Username";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", enteredUsername);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        
                    
                    if (reader.Read())
                        {
                            string storedPassword = reader["Password"].ToString();

                            // Compare the entered password with the stored password
                            if (enteredPassword == storedPassword)
                            {
                                // Login successful
                                MessageBox.Show("Login successful!");

                                // Hide the login form
                                this.Hide();

                                // Create an instance of your homepage form
                                Home_page homepageForm = new Home_page();

                                // Show the homepage form
                                homepageForm.Show();
                                this.Hide();
                            }
                            else
                            {
                                // Incorrect password
                                MessageBox.Show("Incorrect password.");
                            }
                        }
                        else
                        {
                            // User not found
                            MessageBox.Show("User not found.");
                        }

                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Regestratiion homepageForm = new Regestratiion();

            // Show the homepage form
            homepageForm.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Adminlogin Adminloginpage = new Adminlogin();

            // Show the homepage form
            Adminloginpage.Show();
                this.Hide();
        }
    }
}

