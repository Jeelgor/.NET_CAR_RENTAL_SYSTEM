﻿    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    namespace CAR_RENTAL
    {
        public partial class Regestratiion : Form
        {
            public Regestratiion()
            {
                InitializeComponent();
            }

            private void Regestratiion_Load(object sender, EventArgs e)
            {

            }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtuname.Text;
            //string email = txtemail.Text;
            string phoneNumber = txtpno.Text;
            string password = txtpass.Text;
            string confirmPassword = txtcpass.Text;

            // Add validation to ensure password and confirm password match
            if (password != confirmPassword)
            {
                MessageBox.Show("Password and Confirm Password do not match.");
                return;
            }
            if (phoneNumber.Length != 10)
            {
                MessageBox.Show("Phone number should be exactly 10 digits.");
                return;
            }
            // Define your database connection string
            string connectionString = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Check if the username is already in use
                string checkUsernameQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username";
                using (SqlCommand checkUsernameCommand = new SqlCommand(checkUsernameQuery, connection))
                {
                    checkUsernameCommand.Parameters.AddWithValue("@Username", username);
                    int existingUserCount = (int)checkUsernameCommand.ExecuteScalar();

                    if (existingUserCount > 0)
                    {
                        MessageBox.Show("Username is already in use. Please choose a different username.");
                        return;
                    }
                }

                // Insert user data into the database
                string insertQuery = "INSERT INTO Users (Username, PhoneNo, Password) " +
                                     "VALUES (@Username,  @PhoneNo, @Password)";
                using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                {
                    insertCommand.Parameters.AddWithValue("@Username", username);
                    //insertCommand.Parameters.AddWithValue("@Email", email);
                    insertCommand.Parameters.AddWithValue("@PhoneNo", phoneNumber);
                    insertCommand.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        int rowsAffected = insertCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Registration successful.");
                            Login loginForm = new Login();
                            loginForm.ShowDialog();
                            this.Hide();
                            // Close the registration form or take other actions as needed
                        }
                        else
                        {
                            MessageBox.Show("Failed to register. Please try again.");
                            this.Hide();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                        
                    }
                }
            }
        }

        private void Loginbtn2_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            loginForm.ShowDialog();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtuname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


