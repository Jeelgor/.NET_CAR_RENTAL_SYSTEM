﻿namespace CAR_RENTAL
{
    partial class CutomerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CutomerDetails));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtPhno = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPincode = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.ppoint = new System.Windows.Forms.ComboBox();
            this.dpoint = new System.Windows.Forms.ComboBox();
            this.Pickup = new System.Windows.Forms.Label();
            this.Droppoint = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(210, 314);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(211, 449);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Model Name";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(210, 403);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(210, 355);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 22);
            this.label6.TabIndex = 5;
            this.label6.Text = "Phone No";
            // 
            // txtName
            // 
            this.txtName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtName.Location = new System.Drawing.Point(344, 316);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(253, 22);
            this.txtName.TabIndex = 6;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // txtPhno
            // 
            this.txtPhno.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPhno.Location = new System.Drawing.Point(344, 357);
            this.txtPhno.Name = "txtPhno";
            this.txtPhno.Size = new System.Drawing.Size(253, 22);
            this.txtPhno.TabIndex = 7;
            this.txtPhno.TextChanged += new System.EventHandler(this.txtPhno_TextChanged);
            // 
            // txtAddress
            // 
            this.txtAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddress.Location = new System.Drawing.Point(344, 405);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(253, 22);
            this.txtAddress.TabIndex = 9;
            // 
            // txtPincode
            // 
            this.txtPincode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPincode.Location = new System.Drawing.Point(344, 451);
            this.txtPincode.Name = "txtPincode";
            this.txtPincode.Size = new System.Drawing.Size(253, 22);
            this.txtPincode.TabIndex = 10;
            this.txtPincode.TextChanged += new System.EventHandler(this.txtPincode_TextChanged);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(293, 634);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(176, 47);
            this.button1.TabIndex = 11;
            this.button1.Text = "Confirm Order";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ppoint
            // 
            this.ppoint.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ppoint.FormattingEnabled = true;
            this.ppoint.Items.AddRange(new object[] {
            "punit nagar",
            "asman city",
            "150 ft ring road"});
            this.ppoint.Location = new System.Drawing.Point(344, 499);
            this.ppoint.Name = "ppoint";
            this.ppoint.Size = new System.Drawing.Size(253, 24);
            this.ppoint.TabIndex = 12;
            // 
            // dpoint
            // 
            this.dpoint.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dpoint.FormattingEnabled = true;
            this.dpoint.Items.AddRange(new object[] {
            "rku",
            "aji dam"});
            this.dpoint.Location = new System.Drawing.Point(344, 545);
            this.dpoint.Name = "dpoint";
            this.dpoint.Size = new System.Drawing.Size(253, 24);
            this.dpoint.TabIndex = 13;
            // 
            // Pickup
            // 
            this.Pickup.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Pickup.AutoSize = true;
            this.Pickup.BackColor = System.Drawing.Color.Transparent;
            this.Pickup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pickup.Location = new System.Drawing.Point(210, 499);
            this.Pickup.Name = "Pickup";
            this.Pickup.Size = new System.Drawing.Size(113, 22);
            this.Pickup.TabIndex = 14;
            this.Pickup.Text = "PickUp Point";
            // 
            // Droppoint
            // 
            this.Droppoint.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Droppoint.AutoSize = true;
            this.Droppoint.BackColor = System.Drawing.Color.Transparent;
            this.Droppoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Droppoint.Location = new System.Drawing.Point(210, 543);
            this.Droppoint.Name = "Droppoint";
            this.Droppoint.Size = new System.Drawing.Size(95, 22);
            this.Droppoint.TabIndex = 15;
            this.Droppoint.Text = "Drop Point";
            this.Droppoint.Click += new System.EventHandler(this.label7_Click);
            // 
            // CutomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1274, 788);
            this.Controls.Add(this.Droppoint);
            this.Controls.Add(this.Pickup);
            this.Controls.Add(this.dpoint);
            this.Controls.Add(this.ppoint);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtPincode);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtPhno);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "CutomerDetails";
            this.Text = "CutomerDetails";
            this.Load += new System.EventHandler(this.CutomerDetails_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPhno;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPincode;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox ppoint;
        private System.Windows.Forms.ComboBox dpoint;
        private System.Windows.Forms.Label Pickup;
        private System.Windows.Forms.Label Droppoint;
    }
}