﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CAR_RENTAL
{
    public partial class Adminpanel : Form
    {
        public Adminpanel()
        {
            InitializeComponent();
        }

        private void Adminpanel_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String constr = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";


            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string query = "select * from CarRent_data";

            SqlDataAdapter adp1 = new SqlDataAdapter(query, con);
            DataSet ds1 = new DataSet();
            adp1.Fill(ds1);

            alldata.DataSource = ds1.Tables[0];
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            String constr = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";

            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string query = "UPDATE CarRent_data SET Customer_Name=@txtcname,Phone_no=@txtphno, Address=@txtadd,Model_Name=@txtpin,PickUp_Point=@txtppoint,Drop_Point=@txtdpoint where Customer_Name=@txtcname";

            SqlCommand cmd1 = new SqlCommand(query, con);
            cmd1.Parameters.AddWithValue("@txtcname", txtcname.Text);
            cmd1.Parameters.AddWithValue("@txtphno", txtphno.Text);
          //  cmd1.Parameters.AddWithValue("@txtemail", txtemail.Text);
            cmd1.Parameters.AddWithValue("@txtadd", txtadd.Text);
            cmd1.Parameters.AddWithValue("@txtpin", txtpin.Text);
            cmd1.Parameters.AddWithValue("@txtppoint", txtppoint.Text);
            cmd1.Parameters.AddWithValue("@txtdpoint", txtdpoint.Text);

            cmd1.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Update Successfully");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String constr = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";

            SqlConnection con = new SqlConnection(constr);
            con.Open();
            String query = "INSERT INTO CarRent_data(Customer_Name,Phone_no,Address,Pincode,Pickup_Point,Drop_Point) VALUES(@txtcname,@txtphno,@txtadd,@txtpin,@txtppoint,@txtdpoint)";

            SqlCommand cmd1 = new SqlCommand(query, con);

            cmd1.Parameters.AddWithValue("@txtcname", txtcname.Text);
            cmd1.Parameters.AddWithValue("@txtphno", txtphno.Text);
            //cmd1.Parameters.AddWithValue("@txtemail", txtemail.Text);
            cmd1.Parameters.AddWithValue("@txtadd", txtadd.Text);
            cmd1.Parameters.AddWithValue("@txtpin", txtpin.Text);
            cmd1.Parameters.AddWithValue("@txtppoint", txtppoint.Text);
            cmd1.Parameters.AddWithValue("@txtdpoint", txtdpoint.Text);


            cmd1.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Saved Successfully");
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            String constr = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";

            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string query = "delete from CarRent_data WHERE Customer_Name= @txtcname";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@txtcname", txtcname.Text);

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Deleted");
        }
    }
}
