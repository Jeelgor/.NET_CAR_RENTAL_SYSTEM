﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAR_RENTAL
{
    public partial class CarRent_data : Form
    {
        public CarRent_data()
        {
            InitializeComponent();
        }

        private void CarRent_data_Load(object sender, EventArgs e)
        {
            string constr = "Data Source=JEEL\\SQLEXPRESS;Initial Catalog=Book;Integrated Security=True";

            // SQL query to select data from your table (replace "YourTable" with the actual table name)
            string query = "SELECT * FROM CarRent_data";

            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();

                using (SqlDataAdapter adp1 = new SqlDataAdapter(query, con))
                {
                    DataSet ds1 = new DataSet();
                    adp1.Fill(ds1);

                    // Bind the DataGridView to the dataset
                    Carrentdata.DataSource = ds1.Tables[0];

                }
            }
        }
    }
}
