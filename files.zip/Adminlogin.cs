﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CAR_RENTAL
{
    public partial class Adminlogin : Form
    {
        public Adminlogin()
        {
            InitializeComponent();
        }

        private void Adminlogin_Load(object sender, EventArgs e)
        {

        }

        private void labl_Click(object sender, EventArgs e)
        {

        }

        private void Alogin_Click(object sender, EventArgs e)
        {
            string enteredUsername = adminUsernameTextBox.Text;
            string enteredPassword = adminPasswordTextBox.Text;

            if (enteredUsername == "Jeel" && enteredPassword == "Jeel05")
            {
                // Successful admin login
                MessageBox.Show("Admin login successful!");

                // Hide the login form (assuming 'this' refers to the login form)
                this.Hide();

                // Create an instance of your admin panel form
                Adminpanel adminPanelForm = new Adminpanel();

                // Show the admin panel form
                adminPanelForm.Show();
            }
            else if (enteredUsername == "Yash" && enteredPassword == "Yash27")
            {
                // Successful Yash login
                MessageBox.Show("Yash login successful!");

                // Hide the login form (assuming 'this' refers to the login form)
                this.Hide();

                // Create an instance of your user panel form (assuming there's a UserPanel class)
                Adminpanel adminPanelForm = new Adminpanel();

                // Show the admin panel form
                adminPanelForm.Show();
                this.Hide();
            }
            else if (enteredUsername == "Aditya" && enteredPassword == "Aditya24")
            {
                // Successful Yash login
                MessageBox.Show("Aditya login successful!");

                // Hide the login form (assuming 'this' refers to the login form)
                this.Hide();

                // Create an instance of your user panel form (assuming there's a UserPanel class)
                Adminpanel adminPanelForm = new Adminpanel();

                // Show the admin panel form
                adminPanelForm.Show();
                this.Hide();
            }
            else
            {
                // Login failed
                MessageBox.Show("Invalid username or password. Please try again.");
            }

        }
    }
}

